# 🧠 AI/ML Portfolio Website

This is a personal portfolio web app created using Streamlit. It showcases multiple AI/ML and Python projects in a clean, easy-to-navigate interface.

## 📦 How to Run
1. Install the requirements:
```bash
pip install -r requirements.txt
```

2. Run the app:
```bash
streamlit run app.py
```

## 🌟 Projects Included
- AI/ML Quiz Game
- Crop Disease Prediction
- Smart Fertilizer Advisor
- To-Do List Tracker

## ✨ Tech Stack
- Python
- Streamlit

## 📜 License
MIT License
