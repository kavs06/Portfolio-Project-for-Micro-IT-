import streamlit as st

st.set_page_config(page_title="AI/ML Portfolio", layout="wide")

st.title("🧠 AI/ML Portfolio")
st.markdown("Welcome to my AI/ML Project Portfolio! Here's a showcase of projects I've built using Python, machine learning, and data science.")

projects = [
    {
        "title": "1. AI/ML Quiz Game",
        "description": "A terminal-based quiz game that adjusts question difficulty using a Decision Tree model.",
        "tech": "Python, scikit-learn, JSON"
    },
    {
        "title": "2. Crop Disease Prediction",
        "description": "A system that detects crop diseases from images using CNNs and suggests appropriate solutions.",
        "tech": "TensorFlow, Keras, OpenCV"
    },
    {
        "title": "3. Smart Fertilizer Advisor",
        "description": "An app that helps farmers determine the right fertilizer based on soil type and plant deficiency.",
        "tech": "Flask, ML Models, APIs"
    },
    {
        "title": "4. To-Do List Tracker",
        "description": "A simple console app to manage tasks and mark them as completed.",
        "tech": "Python, JSON"
    }
]

for project in projects:
    st.subheader(project["title"])
    st.write(project["description"])
    st.markdown(f"**Tech Stack:** {project['tech']}")
    st.markdown("---")

st.sidebar.title("Contact Info")
st.sidebar.info("👩‍💻 Name: Your Name
📧 Email: your.email@example.com
🌐 GitHub: [yourgithub](https://github.com/yourgithub)")
